module.exports = {
  plugins: {
    'postcss-import': {},
    autoprefixer: {},
    cssnano: {}
  }
};
